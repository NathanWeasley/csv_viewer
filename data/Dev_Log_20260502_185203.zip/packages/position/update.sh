#!/bin/bash
SCRIPT_PATH=$(dirname "$(readlink -f "$0")")
mkdir /robot/system_param/packages/position
cp -f $SCRIPT_PATH/position.json /robot/system_param/packages/position/
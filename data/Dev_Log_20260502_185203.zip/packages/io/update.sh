#!/bin/bash
SCRIPT_PATH=$(dirname "$(readlink -f "$0")")
mkdir /robot/system_param/packages/io
cp -f $SCRIPT_PATH/io.json /robot/system_param/packages/io/

rm -rf mkdir /robot/system_param/packages/io/FIO_

mkdir /robot/system_param/packages/io/DI_
mkdir /robot/system_param/packages/io/DO_
mkdir /robot/system_param/packages/io/GI_
mkdir /robot/system_param/packages/io/GO_
mkdir /robot/system_param/packages/io/NI_
mkdir /robot/system_param/packages/io/NO_
mkdir /robot/system_param/packages/io/RI_
mkdir /robot/system_param/packages/io/RO_
mkdir /robot/system_param/packages/io/FDI_
mkdir /robot/system_param/packages/io/FDO_
mkdir /robot/system_param/packages/io/FGI_
mkdir /robot/system_param/packages/io/FGO_
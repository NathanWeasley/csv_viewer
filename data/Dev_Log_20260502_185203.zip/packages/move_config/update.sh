#!/bin/bash
SCRIPT_PATH=$(dirname "$(readlink -f "$0")")
mkdir /robot/system_param/packages/move_config
cp -f $SCRIPT_PATH/move_config.json /robot/system_param/packages/move_config/
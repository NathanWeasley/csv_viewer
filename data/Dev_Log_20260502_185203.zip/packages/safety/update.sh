#!/bin/bash
SCRIPT_PATH=$(dirname "$(readlink -f "$0")")
mkdir /robot/system_param/packages/safety
cp -f $SCRIPT_PATH/safety.json /robot/system_param/packages/safety/
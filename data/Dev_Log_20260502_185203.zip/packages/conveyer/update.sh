#!/bin/bash

# 获取脚本所在目录的绝对路径
SCRIPT_PATH=$(dirname "$(readlink -f "$0")")

# 更新系统变量函数
# 参数: 目录名前缀
update_sys_var() 
{
    # 参数校验
    if [ -z "\$1" ]; then
        echo "错误: 必须提供目录名前缀参数" >&2
        return 1
    fi

    local dirname="$1"
    local dst_dir="/robot/system_param/packages/conveyer/$dirname"
    local src_dir="${SCRIPT_PATH}/$dirname"

    # 检查源目录是否存在
    if [ ! -d "$src_dir" ]; then
        echo "错误: 源目录 $src_dir 不存在" >&2
        return 1
    fi

    # 创建目标目录(如果不存在)并复制内容
    if [ ! -d "$dst_dir" ]; then
        if ! mkdir -p "$dst_dir"; then
            echo "错误: 无法创建目录 $dst_dir" >&2
            return 1
        fi
        
        if ! cp -rf "$src_dir" "/robot/system_param/packages/conveyer/"; then
            echo "错误: 无法复制 $src_dir 到目标位置" >&2
            return 1
        fi
        echo "成功更新系统变量: $dirname"
    else
        echo "目录 $dst_dir 已存在，跳过更新"
    fi
}


# 创建基础目录
if ! mkdir -p "/robot/system_param/packages/conveyer"; then
    echo "错误: 无法创建基础目录" >&2
fi

if ! cp -f "${SCRIPT_PATH}/conveyer.json" "/robot/system_param/packages/conveyer/"; then
    echo "错误: 无法复制 conveyer.json" >&2
fi

if ! cp -f "${SCRIPT_PATH}"/*.prl "/robot/system_param/packages/conveyer/"; then
    echo "错误: 无法复制 conveyer的prl文件" >&2
fi

if ! cp -f "${SCRIPT_PATH}"/*.dat "/robot/system_param/packages/conveyer/"; then
    echo "错误: 无法复制 conveyer的dat文件" >&2
fi


# 更新系统变量
update_sys_var "CONV_"
update_sys_var "OBJECT_"
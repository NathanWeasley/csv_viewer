#!/bin/bash
SCRIPT_PATH=$(dirname "$(readlink -f "$0")")
mkdir /robot/system_param/packages/math
cp -f $SCRIPT_PATH/math.json /robot/system_param/packages/math/
#!/bin/bash
SCRIPT_PATH=$(dirname "$(readlink -f "$0")")

update_sys_var()
{
	dirname=$1
	dst_dir="/robot/system_param/packages/debug/$dirname"
	#echo $dst_dir
	src_dir="$SCRIPT_PATH/$dirname/*"
	#echo $src_dir
	if [ ! -d $dst_dir ];then
		mkdir -p $dst_dir
	fi
	cp -rn $src_dir $dst_dir
}

mkdir /robot/system_param/packages/debug
cp -f $SCRIPT_PATH/debug.json /robot/system_param/packages/debug/

update_sys_var "calib_"
update_sys_var "calib_jnt_"
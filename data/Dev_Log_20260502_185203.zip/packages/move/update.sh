#!/bin/bash
SCRIPT_PATH=$(dirname "$(readlink -f "$0")")

update_sys_var()
{
	dirname=$1
	dst_dir="/robot/system_param/packages/move/$dirname"
	#echo $dst_dir
	src_dir="$SCRIPT_PATH/$dirname/*"
	#echo $src_dir
	if [ ! -d $dst_dir ];then
		mkdir -p $dst_dir
		cp -rn $src_dir  $dst_dir
	fi
}


mkdir /robot/system_param/packages/move
mkdir /robot/system_param/packages/move/Home
cp -f $SCRIPT_PATH/move.json /robot/system_param/packages/move/
cp -f $SCRIPT_PATH/*.dat /robot/system_param/packages/move/

#内置变量强制替换
cp -rf $SCRIPT_PATH/V  /robot/system_param/packages/move/
cp -rf $SCRIPT_PATH/PL  /robot/system_param/packages/move/
cp -rf $SCRIPT_PATH/Fine  /robot/system_param/packages/move/
cp -rf $SCRIPT_PATH/Base  /robot/system_param/packages/move/
cp -rf $SCRIPT_PATH/TOOL_0  /robot/system_param/packages/move/
cp -rf $SCRIPT_PATH/LOAD_0  /robot/system_param/packages/move/

#用户变量首次替换
update_sys_var "INT_"
update_sys_var "DOUBLE_"
update_sys_var "JNT_"
update_sys_var "POSE_"
update_sys_var "TOOL_"
update_sys_var "CS_"
update_sys_var "LOAD_"
update_sys_var "EXLOAD_"
update_sys_var "ZONE_"
update_sys_var "World"
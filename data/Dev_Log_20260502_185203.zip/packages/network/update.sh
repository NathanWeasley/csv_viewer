#!/bin/bash
SCRIPT_PATH=$(dirname "$(readlink -f "$0")")
mkdir /robot/system_param/packages/network
cp -f $SCRIPT_PATH/network.json /robot/system_param/packages/network/
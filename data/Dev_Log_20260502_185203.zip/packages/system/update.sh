#!/bin/bash
SCRIPT_PATH=$(dirname "$(readlink -f "$0")")
mkdir /robot/system_param/packages/system
cp -f $SCRIPT_PATH/system.json /robot/system_param/packages/system/
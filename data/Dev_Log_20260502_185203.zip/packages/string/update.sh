#!/bin/bash
SCRIPT_PATH=$(dirname "$(readlink -f "$0")")
mkdir /robot/system_param/packages/string
cp -f $SCRIPT_PATH/string.json /robot/system_param/packages/string/